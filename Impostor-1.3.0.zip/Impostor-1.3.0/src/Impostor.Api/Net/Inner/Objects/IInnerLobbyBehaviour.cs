﻿namespace Impostor.Api.Net.Inner.Objects
{
    public interface IInnerLobbyBehaviour : IInnerNetObject
    {
    }
}
