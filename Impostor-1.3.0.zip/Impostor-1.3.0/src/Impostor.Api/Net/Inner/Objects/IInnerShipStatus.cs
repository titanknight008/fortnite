﻿namespace Impostor.Api.Net.Inner.Objects
{
    public interface IInnerShipStatus : IInnerNetObject
    {
    }
}
