﻿namespace Impostor.Api.Net.Inner.Objects
{
    public interface IInnerMeetingHud : IInnerNetObject
    {
    }
}
