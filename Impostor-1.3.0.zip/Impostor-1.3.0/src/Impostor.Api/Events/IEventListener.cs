﻿namespace Impostor.Api.Events
{
    public interface IEventListener
    {
    }
}
