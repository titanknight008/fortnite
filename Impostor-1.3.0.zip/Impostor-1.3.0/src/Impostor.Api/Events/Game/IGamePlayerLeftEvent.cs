﻿namespace Impostor.Api.Events
{
    public interface IGamePlayerLeftEvent : IGameEvent
    {
    }
}
