﻿namespace Impostor.Api.Events.Meeting
{
    public interface IMeetingEndedEvent : IMeetingEvent
    {
    }
}
