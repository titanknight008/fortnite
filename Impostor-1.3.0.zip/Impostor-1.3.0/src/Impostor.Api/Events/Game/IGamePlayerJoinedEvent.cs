﻿namespace Impostor.Api.Events
{
    public interface IGamePlayerJoinedEvent : IGameEvent
    {
    }
}
