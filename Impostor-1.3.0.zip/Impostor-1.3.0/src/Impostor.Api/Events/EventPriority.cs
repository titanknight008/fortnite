﻿namespace Impostor.Api.Events
{
    public enum EventPriority
    {
        Lowest = 0,
        Low = 1,
        Normal = 2,
        High = 3,
        Highest = 4,
        Monitor = 5,
    }
}
