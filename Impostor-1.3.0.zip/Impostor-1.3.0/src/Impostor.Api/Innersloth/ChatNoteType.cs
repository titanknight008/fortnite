﻿namespace Impostor.Api.Innersloth
{
    public enum ChatNoteType : byte
    {
        DidVote = 0,
    }
}
