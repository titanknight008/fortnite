﻿namespace Impostor.Api.Innersloth
{
    public enum AlterGameTags : byte
    {
        ChangePrivacy = 1,
    }
}
