namespace Impostor.Api.Innersloth
{
    public enum Language
    {
        English,
        Spanish,
        Portuguese,
        Korean,
        Russian,
    }
}
