namespace Impostor.Api.Innersloth.Customization
{
    public enum PetType : uint
    {
        NoPet = 0,
        Alien = 1,
        Crewmate = 2,
        Doggy = 3,
        Stickmin = 4,
        Hamster = 5,
        Robot = 6,
        Ufo = 7,
        Ellie = 8,
        Squig = 9,
        Bedcrab = 10,
        Glitch = 11,
    }
}
