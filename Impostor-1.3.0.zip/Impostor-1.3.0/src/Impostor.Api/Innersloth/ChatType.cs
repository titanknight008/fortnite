namespace Impostor.Api.Innersloth
{
    public enum ChatType
    {
        FreeChatOrQuickChat = 1,
        QuickChatOnly = 2,
    }
}
