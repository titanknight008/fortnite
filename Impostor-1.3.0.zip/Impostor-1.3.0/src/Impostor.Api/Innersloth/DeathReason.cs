﻿namespace Impostor.Api.Innersloth
{
    public enum DeathReason
    {
        Exile = 0,
        Kill = 1,
        Disconnect = 2,
    }
}
