using System;

namespace Impostor.Api.Innersloth
{
    [Flags]
    public enum FreeWeekendState : byte
    {
        NotFree,
        FreeMIRA,
        FreePolus,
    }
}
