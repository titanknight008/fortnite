namespace Impostor.Server.Utils
{
    public class ServerEnvironment
    {
        public bool IsReplay { get; init; }
    }
}
