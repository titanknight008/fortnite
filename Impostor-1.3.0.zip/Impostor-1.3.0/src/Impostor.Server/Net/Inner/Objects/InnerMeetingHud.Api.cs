﻿using Impostor.Api.Net.Inner.Objects;

namespace Impostor.Server.Net.Inner.Objects
{
    internal partial class InnerMeetingHud : IInnerMeetingHud
    {
    }
}
