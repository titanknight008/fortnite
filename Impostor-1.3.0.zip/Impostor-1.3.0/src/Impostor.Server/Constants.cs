﻿namespace Impostor.Server
{
    internal static class Constants
    {
        public const int SpawnTimeout = 2500;
        public const int ConnectionTimeout = 2500;
    }
}
