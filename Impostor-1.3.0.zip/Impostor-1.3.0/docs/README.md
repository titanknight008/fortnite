# Impostor Documentation

1. [Running the server](Running-the-server.md)
2. [Server configuration](Server-configuration.md)
3. [Building from source](Building-from-source.md)
4. [Writing a plugin](Writing-a-plugin.md)
5. [Frequently answered questions](FAQ.md)