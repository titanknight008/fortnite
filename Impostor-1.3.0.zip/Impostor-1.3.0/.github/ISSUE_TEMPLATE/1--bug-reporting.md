---
name: 1. Bug reporting
about: Bugs within Impostor
title: ''
labels: ''
assignees: ''

---

# Bug Report

## Base Information
- Operating System
- Impostor Version
- Among Us Version

## I confirm:
- [ ] that I have searched for an existing bug report for this issue.


## Symptoms 

<!--
Write symptoms here.
-->

Enter Symptoms on this line.

## Reproduction

<!--
 How do you reproduce the bug you have here.
-->

Enter reproductions steps here.
